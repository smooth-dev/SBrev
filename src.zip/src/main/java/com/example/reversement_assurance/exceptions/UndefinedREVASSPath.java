package com.example.reversement_assurance.exceptions;

public class UndefinedREVASSPath extends Exception {

        private static final long serialVersionUID = 1L;

        public UndefinedREVASSPath(String message) {
            super(message);
        }

}
