package com.example.reversement_assurance.exceptions;

public class UndefinedPDDDOSPath extends Exception {

        private static final long serialVersionUID = 1L;

        public UndefinedPDDDOSPath(String message) {
            super(message);
        }

}
